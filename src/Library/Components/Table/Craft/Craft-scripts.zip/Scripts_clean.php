<?php
namespace Incodiy\Codiy\Library\Components\Table\Craft;

/**
 * Created on 22 May 2021
 * Time Created : 00:29:19
 *
 * @filesource Scripts.php
 *
 * @author    wisnuwidi@incodiy.com - 2021
 * @copyright wisnuwidi
 * @email     wisnuwidi@incodiy.com
 */
 
trait Scripts {
	
	// HTTP Configuration
	private $datatablesMode = 'GET';
	private $strictGetUrls  = true;
	private $strictColumns  = true;
	
	// DataTables Configuration Constants
	private const DEFAULT_SCROLL_HEIGHT = 300;
	private const MAX_ROWS_LIMIT = 9999999999;
	private const DEFAULT_SEARCH_DELAY = 1000;
	private const DEFAULT_PAGE_LIMITS = [10, 25, 50, 100, 250, 500, 1000];
	private const DEFAULT_ONLOAD_LIMIT = 10;
	
	// Security Constants
	private const ALLOWED_HTTP_METHODS = ['GET', 'POST'];
	private const ALLOWED_OPERATORS = ['=', '==', '===', '<', '<=', '>', '>=', 'LIKE', 'NOT LIKE'];
	private const ALLOWED_TARGETS = ['row', 'cell', 'column'];
	private const ALLOWED_RULES = ['prefix', 'suffix', 'prefix&suffix', 'replace'];
	
	// JavaScript Template Constants
	private const JS_WRAPPER_TEMPLATE = '<script type="text/javascript">jQuery(function($) {%s});%s</script>';
	private const DATATABLE_BASIC_OPTIONS = [
		'searching' => true,
		'processing' => true,
		'retrieve' => false,
		'paginate' => true,
		'responsive' => false,
		'autoWidth' => false,
		'dom' => 'lBfrtip',
		'bDeferRender' => true
	];
	
	/**
	 * Javascript Config for Rendering Datatables
	 *
	 * @param string $attr_id Table ID attribute
	 * @param string $columns Column configurations
	 * @param array $data_info Data table information and settings
	 * @param bool $server_side Enable server-side processing
	 * @param bool|array $filters Filter configurations
	 * @param bool|string|array $custom_link Custom link configurations
	 * @return string Generated JavaScript code
	 * @throws \InvalidArgumentException When invalid parameters provided
	 */
	protected function datatables($attr_id, $columns, $data_info = [], $server_side = false, $filters = false, $custom_link = false) {
		// Validate input parameters
		$this->validateDatatableParameters($attr_id, $columns, $data_info);
		
		// Extract table configuration
		$config = $this->extractTableConfiguration($attr_id, $data_info);
		
		// Build DataTable options
		$options = $this->buildDatatableOptions($attr_id, $columns, $data_info, $server_side, $filters, $custom_link, $config);
		
		// Generate final JavaScript
		return $this->generateDatatableScript($attr_id, $options, $config);
	}
	
	/**
	 * Validate datatable input parameters
	 *
	 * @param string $attr_id
	 * @param string $columns
	 * @param array $data_info
	 * @throws \InvalidArgumentException
	 */
	private function validateDatatableParameters($attr_id, $columns, $data_info) {
		if (empty($attr_id) || !is_string($attr_id)) {
			throw new \InvalidArgumentException('Table ID must be a non-empty string');
		}
		
		if (!is_string($columns)) {
			throw new \InvalidArgumentException('Columns must be a string');
		}
		
		if (!is_array($data_info)) {
			throw new \InvalidArgumentException('Data info must be an array');
		}
		
		// Validate HTTP method if specified
		if (!empty($data_info['http_method']) && !in_array(strtoupper($data_info['http_method']), self::ALLOWED_HTTP_METHODS)) {
			throw new \InvalidArgumentException('Invalid HTTP method specified');
		}
	}
	
	/**
	 * Extract and prepare table configuration
	 *
	 * @param string $attr_id
	 * @param array $data_info
	 * @return array
	 */
	private function extractTableConfiguration($attr_id, $data_info) {
		return [
			'table_id' => $attr_id,
			'var_table_id' => str_replace('-', '', $attr_id),
			'current_url' => url(diy_current_route()->uri),
			'http_method' => $this->determineHttpMethod($data_info),
			'has_fixed_columns' => !empty($data_info['fixed_columns']),
			'fixed_columns_data' => $data_info['fixed_columns'] ?? null,
			'has_conditions' => !empty($data_info['conditions']['columns']),
			'conditions_data' => $data_info['conditions'] ?? null,
			'table_name' => $data_info['name'] ?? null,
			'columns_data' => $data_info['columns'] ?? []
		];
	}
	
	/**
	 * Build complete DataTable options
	 *
	 * @param string $attr_id
	 * @param string $columns
	 * @param array $data_info
	 * @param bool $server_side
	 * @param bool|array $filters
	 * @param bool|string|array $custom_link
	 * @param array $config
	 * @return array
	 */
	private function buildDatatableOptions($attr_id, $columns, $data_info, $server_side, $filters, $custom_link, $config) {
		$options = [
			'basic_options' => $this->buildBasicOptions($data_info),
			'buttons' => $this->buildButtonsConfiguration($attr_id),
			'length_menu' => $this->buildLengthMenuConfiguration($data_info),
			'columns' => $columns,
			'server_side' => $server_side,
			'filters' => $filters,
			'custom_link' => $custom_link,
			'conditional_js' => null,
			'ajax_config' => null,
			'init_complete' => null,
			'click_actions' => null,
			'filter_components' => null
		];
		
		// Build conditional columns if exists
		if ($config['has_conditions']) {
			$options['conditional_js'] = $this->conditionalColumns(
				"cody_{$config['var_table_id']}_dt", 
				$config['conditions_data']['columns'], 
				$config['columns_data']
			);
		}
		
		// Build server-side specific configurations
		if ($server_side) {
			$options = array_merge($options, $this->buildServerSideOptions($attr_id, $data_info, $custom_link, $config));
		}
		
		return $options;
	}
	
	/**
	 * Build basic DataTable options
	 *
	 * @param array $data_info
	 * @return string
	 */
	private function buildBasicOptions($data_info) {
		$options = [];
		
		// Build fixed columns configuration
		if (!empty($data_info['fixed_columns'])) {
			$fixedColumnData = json_encode($data_info['fixed_columns']);
			$options[] = "scrollY:" . self::DEFAULT_SCROLL_HEIGHT;
			$options[] = "scrollX:true";
			$options[] = "scrollCollapse:true";
			$options[] = "fixedColumns:" . $fixedColumnData;
		}
		
		// Add basic configurations
		foreach (self::DATATABLE_BASIC_OPTIONS as $key => $value) {
			if ($key === 'dom') {
				$options[] = "\"{$key}\":\"{$value}\"";
			} else {
				$boolValue = $value ? 'true' : 'false';
				$options[] = "\"{$key}\":{$boolValue}";
			}
		}
		
		// Add search delay
		$options[] = '"searchDelay":' . self::DEFAULT_SEARCH_DELAY;
		
		return implode(',', $options);
	}
	
	/**
	 * Build buttons configuration
	 *
	 * @param string $attr_id
	 * @return string
	 */
	private function buildButtonsConfiguration($attr_id) {
		$buttonConfig = 'exportOptions:{columns:":visible:not(:last-child)"}';
		
		return $this->setButtons($attr_id, [
			'excel|text:"<i class=\"fa fa-external-link\" aria-hidden=\"true\"></i> <u>E</u>xcel"|key:{key:"e",altKey:true}',
			'csv|' . $buttonConfig,
			'pdf|' . $buttonConfig,
			'copy|' . $buttonConfig,
			'print|' . $buttonConfig
		]);
	}
	
	/**
	 * Build length menu configuration
	 *
	 * @param array $data_info
	 * @return string
	 */
	private function buildLengthMenuConfiguration($data_info) {
		$limitRowsData = array_merge(self::DEFAULT_PAGE_LIMITS, [self::MAX_ROWS_LIMIT]);
		$onloadRowsLimit = [self::DEFAULT_ONLOAD_LIMIT];
		
		// Process onload limit rows configuration
		if (!empty($data_info['onload_limit_rows'])) {
			$onloadLimit = $this->processOnloadLimit($data_info['onload_limit_rows']);
			if ($onloadLimit !== null) {
				$onloadRowsLimit = [$onloadLimit];
				// Remove the selected limit from default options to avoid duplication
				$key = array_search($onloadLimit, $limitRowsData);
				if ($key !== false) {
					unset($limitRowsData[$key]);
				}
				$limitRowsData = array_merge($onloadRowsLimit, $limitRowsData);
			}
		}
		
		// Build display labels
		$limitRowsDataString = [];
		foreach ($limitRowsData as $limit) {
			$limitRowsDataString[] = ($limit == self::MAX_ROWS_LIMIT) ? "Show All" : $limit . " Rows";
		}
		
		$lengthMenu = json_encode([$limitRowsData, $limitRowsDataString]);
		return "lengthMenu:{$lengthMenu}";
	}
	
	/**
	 * Process onload limit configuration
	 *
	 * @param mixed $onloadLimit
	 * @return int|null
	 */
	private function processOnloadLimit($onloadLimit) {
		if (is_string($onloadLimit)) {
			if (in_array(strtolower($onloadLimit), ['*', 'all'])) {
				return self::MAX_ROWS_LIMIT;
			}
			return intval($onloadLimit);
		}
		
		if (is_numeric($onloadLimit)) {
			return intval($onloadLimit);
		}
		
		return null;
	}
	
	/**
	 * Build server-side specific options
	 *
	 * @param string $attr_id
	 * @param array $data_info
	 * @param mixed $custom_link
	 * @param array $config
	 * @return array
	 */
	private function buildServerSideOptions($attr_id, $data_info, $custom_link, $config) {
		$options = [];
		
		// Build AJAX configuration
		$options['ajax_config'] = $this->buildAjaxConfiguration($attr_id, $data_info, $custom_link, $config);
		
		// Build init complete
		$options['init_complete'] = $this->initComplete($attr_id, false);
		
		// Build click actions
		$options['click_actions'] = $this->buildClickActions($attr_id, $config);
		
		// Build filter components if needed
		if ($filters !== false) {
			$options['filter_components'] = $this->buildFilterComponents($attr_id, $data_info, $config);
		}
		
		return $options;
	}
	
	/**
	 * Build AJAX configuration for server-side processing
	 *
	 * @param string $attr_id
	 * @param array $data_info
	 * @param mixed $custom_link
	 * @param array $config
	 * @return string
	 */
	private function buildAjaxConfiguration($attr_id, $data_info, $custom_link, $config) {
		// Determine URL and method
		$httpMethod = $config['http_method'];
		$current_url = $config['current_url'];
		
		// Build link URL
		$diftaURI = "&difta[name]={$config['table_name']}&difta[source]=dynamics";
		$link_url = "renderDataTables=true{$diftaURI}";
		
		if ($custom_link !== false) {
			$link_url = $this->buildCustomLinkUrl($custom_link);
		}
		
		// Build script URI based on HTTP method
		$scriptURI = ($httpMethod === 'POST') ? $current_url : "{$current_url}?{$link_url}";
		
		// Build AJAX configuration based on method
		if ($httpMethod === 'POST') {
			return $this->buildPostAjaxConfig($scriptURI, $config);
		} else {
			return $this->buildGetAjaxConfig($scriptURI, $attr_id);
		}
	}
	
	/**
	 * Build POST AJAX configuration
	 *
	 * @param string $scriptURI
	 * @param array $config
	 * @return string
	 */
	private function buildPostAjaxConfig($scriptURI, $config) {
		$token = csrf_token();
		$tableName = htmlspecialchars($config['table_name'], ENT_QUOTES, 'UTF-8');
		
		return "ajax:{" .
			"url:'{$scriptURI}'," .
			"type:'POST'," .
			"headers:{'X-CSRF-TOKEN': '{$token}','Content-Type': 'application/x-www-form-urlencoded'}," .
			"data: function(d) { " .
				"d.renderDataTables = 'true'; " .
				"d['difta[name]'] = '{$tableName}'; " .
				"d['difta[source]'] = 'dynamics'; " .
				"return d; " .
			"} " .
		"}";
	}
	
	/**
	 * Build GET AJAX configuration
	 *
	 * @param string $scriptURI
	 * @param string $attr_id
	 * @return string
	 */
	private function buildGetAjaxConfig($scriptURI, $attr_id) {
		$ajaxLimitGetURLs = '';
		
		if ($this->strictGetUrls) {
			$idString = str_replace('-', '', $attr_id);
			$strictColumns = $this->strictColumns ? 'true' : 'false';
			$ajaxLimitGetURLs = ",data: function (data) {" .
				"var diyDUDC{$idString} = data; " .
				"deleteUnnecessaryDatatableComponents(diyDUDC{$idString}, {$strictColumns})" .
			"}";
		}
		
		return "ajax:{ url:'{$scriptURI}'{$ajaxLimitGetURLs} }";
	}
	
	/**
	 * Build custom link URL
	 *
	 * @param mixed $custom_link
	 * @return string
	 */
	private function buildCustomLinkUrl($custom_link) {
		if (is_array($custom_link)) {
			$key = htmlspecialchars($custom_link[0], ENT_QUOTES, 'UTF-8');
			$value = htmlspecialchars($custom_link[1], ENT_QUOTES, 'UTF-8');
			return "{$key}={$value}";
		}
		
		$sanitized_link = htmlspecialchars($custom_link, ENT_QUOTES, 'UTF-8');
		return "{$sanitized_link}=true";
	}
	
	/**
	 * Build click actions for table rows
	 *
	 * @param string $attr_id
	 * @param array $config
	 * @return string
	 */
	private function buildClickActions($attr_id, $config) {
		$url_path = htmlspecialchars($config['current_url'], ENT_QUOTES, 'UTF-8');
		$hash = hash_code_id();
		
		return ".on('click','td.clickable', function(){" .
			"var getRLP = $(this).parent('tr').attr('rlp'); " .
			"if(getRLP != false) { " .
				"var _rlp = parseInt(getRLP.replace('{$hash}','')-8*800/80); " .
				"window.location='{$url_path}/'+_rlp+'/edit'; " .
			"} " .
		"});";
	}
	
	/**
	 * Build filter components
	 *
	 * @param string $attr_id
	 * @param array $data_info
	 * @param array $config
	 * @return array
	 */
	private function buildFilterComponents($attr_id, $data_info, $config) {
		$components = [];
		
		// Build filter button
		$components['button'] = "$('div#{$attr_id}_wrapper>.dt-buttons').append('<span class=\"cody_{$attr_id}_diy-dt-filter-box\"></span>')";
		
		// Build filter JS
		$scriptURI = ($config['http_method'] === 'POST') ? $config['current_url'] : "{$config['current_url']}?renderDataTables=true";
		$components['js'] = $this->filter($attr_id, $scriptURI);
		
		// Build export functionality
		$diftaURI = "&difta[name]={$config['table_name']}&difta[source]=dynamics";
		$exportURI = route('ajax.export') . "?exportDataTables=true{$diftaURI}";
		$connection = !empty($this->connection) ? "::{$this->connection}" : '';
		$components['export'] = $this->export($attr_id . $connection, $exportURI);
		
		return $components;
	}
	
	/**
	 * Generate final DataTable script
	 *
	 * @param string $attr_id
	 * @param array $options
	 * @param array $config
	 * @return string
	 */
	private function generateDatatableScript($attr_id, $options, $config) {
		$varTableID = $config['var_table_id'];
		
		// Build main DataTable initialization
		$mainScript = $this->buildMainDatatableScript($attr_id, $varTableID, $options, $config);
		
		// Build document ready script
		$documentReadyScript = $this->buildDocumentReadyScript($attr_id, $options);
		
		// Combine scripts using template
		return sprintf(
			self::JS_WRAPPER_TEMPLATE,
			$mainScript,
			$documentReadyScript
		);
	}
	
	/**
	 * Build main DataTable script
	 *
	 * @param string $attr_id
	 * @param string $varTableID
	 * @param array $options
	 * @param array $config
	 * @return string
	 */
	private function buildMainDatatableScript($attr_id, $varTableID, $options, $config) {
		$script = "cody_{$varTableID}_dt = $('#{$attr_id}').DataTable({";
		
		// Add responsive row reorder
		$script .= "rowReorder :{selector:'td:nth-child(2)'},responsive: false,";
		
		// Add basic options
		$script .= $options['basic_options'] . ',';
		
		// Add buttons
		$script .= '"buttons":' . $options['buttons'] . ',';
		
		// Add length menu
		$script .= $options['length_menu'] . ',';
		
		// Add server-side specific options
		if ($options['server_side']) {
			$script .= "'serverSide':true,";
			$script .= $options['ajax_config'] . ',';
			
			// Add column definitions
			$colDefs = "columnDefs:[{target:[1],visible:false,searchable:false,className:'control hidden-column'}]";
			$orderColumn = "order:[[1,'desc']]";
			$script .= "columns:{$options['columns']},{$orderColumn},{$colDefs},";
			
			// Add init complete
			$script .= $options['init_complete'];
			
			// Add conditional columns
			if ($options['conditional_js']) {
				$script .= $options['conditional_js'];
			}
		} else {
			$script .= "columns:{$options['columns']}";
		}
		
		$script .= "})";
		
		// Add click actions
		if (!empty($options['click_actions'])) {
			$script .= $options['click_actions'];
		}
		
		// Add filter button
		if (!empty($options['filter_components']['button'])) {
			$script .= $options['filter_components']['button'];
		}
		
		return $script;
	}
	
	/**
	 * Build document ready script
	 *
	 * @param string $attr_id
	 * @param array $options
	 * @return string
	 */
	private function buildDocumentReadyScript($attr_id, $options) {
		$scripts = [];
		$scripts[] = "$(document).ready(function() {";
		$scripts[] = "$('#{$attr_id}').wrap('<div class=\"diy-wrapper-table\"></div>');";
		
		// Add filter JS
		if (!empty($options['filter_components']['js'])) {
			$scripts[] = $options['filter_components']['js'] . ';';
		}
		
		// Add export functionality
		if (!empty($options['filter_components']['export'])) {
			$scripts[] = $options['filter_components']['export'] . ';';
		}
		
		// Add fixed column styling
		$scripts[] = "$('.dtfc-fixed-left').last().addClass('last-of-scrool-column-table');";
		
		$scripts[] = "});";
		
		return implode(' ', $scripts);
	}
	
	/**
	 * Determine HTTP method based on data info and fallback logic
	 * 
	 * @param array $data_info
	 * @return string
	 */
	private function determineHttpMethod($data_info) {
		// Priority order: data_info method > class method > default GET
		if (!empty($data_info['http_method'])) {
			return strtoupper($data_info['http_method']);
		}
		
		if (!empty($this->method)) {
			return strtoupper($this->method);
		}
		
		// Check if secure mode is enabled
		if (!empty($data_info['secure_mode']) && $data_info['secure_mode'] === true) {
			return 'POST';
		}
		
		// Default to GET for backward compatibility
		return 'GET';
	}
	
	private function getJsContainMatch($data, $match_contained = null) {
		if ('!=' === $match_contained || '!==' === $match_contained) $match = false;
		if ('==' === $match_contained || '===' === $match_contained) $match = true;
		
		if (true  == $match) return ":contains(\"{$data}\")";
		if (false == $match) return ":not(:contains(\"{$data}\"))";		
	}
	
	/**
	 * Generate conditional columns JavaScript with enhanced security
	 *
	 * @param string $tableIdentity
	 * @param array $data
	 * @param array $columns
	 * @return string|null
	 */
	private function conditionalColumns($tableIdentity, $data, $columns) {
		if (empty($data) || !is_array($data) || !is_array($columns)) {
			return null;
		}
		
		// Sanitize table identity
		$tableIdentity = preg_replace('/[^a-zA-Z0-9_]/', '_', $tableIdentity);
		
		// Build column index mapping
		$icols = $this->buildColumnMapping($columns);
		
		// Process and validate conditions
		$processedData = $this->processConditions($data, $icols);
		
		if (empty($processedData)) {
			return null;
		}
		
		// Generate JavaScript
		return $this->generateConditionalJS($processedData);
	}
	
	/**
	 * Build column mapping for safe index access
	 *
	 * @param array $columns
	 * @return array
	 */
	private function buildColumnMapping($columns) {
		$icols = [];
		foreach ($columns as $i => $v) {
			// Sanitize column names to prevent XSS
			$sanitizedColumn = htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
			$icols[$sanitizedColumn] = intval($i);
		}
		return $icols;
	}
	
	/**
	 * Process and validate conditions
	 *
	 * @param array $data
	 * @param array $icols
	 * @return array
	 */
	private function processConditions($data, $icols) {
		$processedData = [];
		
		foreach ($data as $idx => $condition) {
			$processedCondition = $this->validateAndSanitizeCondition($condition, $icols);
			if ($processedCondition !== null) {
				$processedData[] = $processedCondition;
			}
		}
		
		return $processedData;
	}
	
	/**
	 * Validate and sanitize individual condition
	 *
	 * @param array $condition
	 * @param array $icols
	 * @return array|null
	 */
	private function validateAndSanitizeCondition($condition, $icols) {
		// Validate required fields
		if (empty($condition['logic_operator']) || empty($condition['field_name'])) {
			return null;
		}
		
		// Validate operator
		if (!in_array($condition['logic_operator'], self::ALLOWED_OPERATORS)) {
			return null;
		}
		
		// Validate target
		$fieldTarget = $condition['field_target'] ?? 'row';
		if (!in_array($fieldTarget, self::ALLOWED_TARGETS)) {
			return null;
		}
		
		// Validate rule
		$rule = $condition['rule'] ?? 'replace';
		if (!in_array($rule, self::ALLOWED_RULES)) {
			return null;
		}
		
		// Sanitize field names
		$fieldName = htmlspecialchars($condition['field_name'], ENT_QUOTES, 'UTF-8');
		$sanitizedTarget = htmlspecialchars($fieldTarget, ENT_QUOTES, 'UTF-8');
		
		// Build node mapping
		$node = [
			'field_name' => $icols[$fieldName] ?? null,
			'field_target' => isset($icols[$sanitizedTarget]) ? $icols[$sanitizedTarget] : null
		];
		
		return [
			'logic_operator' => $condition['logic_operator'],
			'field_name' => $fieldName,
			'field_target' => $sanitizedTarget,
			'rule' => htmlspecialchars($rule, ENT_QUOTES, 'UTF-8'),
			'action' => $this->sanitizeAction($condition['action'] ?? '', $rule),
			'value' => $this->sanitizeValue($condition['value'] ?? ''),
			'node' => $node
		];
	}
	
	/**
	 * Sanitize action value based on rule type
	 *
	 * @param mixed $action
	 * @param string $rule
	 * @return mixed
	 */
	private function sanitizeAction($action, $rule) {
		if (is_array($action)) {
			return array_map(function($item) {
				return htmlspecialchars($item, ENT_QUOTES, 'UTF-8');
			}, $action);
		}
		
		// For CSS properties, allow only safe values
		if (in_array($rule, ['background-color', 'color', 'font-weight'])) {
			return preg_replace('/[^a-zA-Z0-9\-#\s]/', '', $action);
		}
		
		return htmlspecialchars($action, ENT_QUOTES, 'UTF-8');
	}
	
	/**
	 * Sanitize condition value
	 *
	 * @param mixed $value
	 * @return mixed
	 */
	private function sanitizeValue($value) {
		if (is_array($value)) {
			return array_map(function($item) {
				return htmlspecialchars($item, ENT_QUOTES, 'UTF-8');
			}, $value);
		}
		
		return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
	}
	
	/**
	 * Generate conditional JavaScript
	 *
	 * @param array $processedData
	 * @return string
	 */
	private function generateConditionalJS($processedData) {
		$js = ", 'createdRow': function(row, data, dataIndex, cells) {";
		
		foreach ($processedData as $condition) {
			$js .= $this->buildConditionLogic($condition);
			$js .= $this->buildConditionActions($condition);
			$js .= "}";
		}
		
		$js .= "}";
		return $js;
	}
	
	/**
	 * Build condition logic part
	 *
	 * @param array $condition
	 * @return string
	 */
	private function buildConditionLogic($condition) {
		$operator = $condition['logic_operator'];
		$fieldName = $condition['field_name'];
		$value = $condition['value'];
		
		if (in_array($operator, ['=', '==', '===', '<', '<=', '>', '>='])) {
			return "if (data.{$fieldName} {$operator} '{$value}') {";
		}
		
		// Handle LIKE operators
		$isNot = (strpos($operator, 'NOT') === 0) ? '!' : '';
		
		if (is_array($value)) {
			$conditions = [];
			foreach ($value as $val) {
				$conditions[] = "{$isNot}~data.{$fieldName}.indexOf('{$val}')";
			}
			$conditionStr = implode(' && ', $conditions);
		} else {
			$conditionStr = "{$isNot}~data.{$fieldName}.indexOf('{$value}')";
		}
		
		return "if ({$conditionStr}) {";
	}
	
	/**
	 * Build condition actions part
	 *
	 * @param array $condition
	 * @return string
	 */
	private function buildConditionActions($condition) {
		$target = $condition['field_target'];
		$rule = $condition['rule'];
		$action = $condition['action'];
		$node = $condition['node'];
		
		switch ($target) {
			case 'row':
				return $this->buildRowActions($rule, $action);
			
			case 'cell':
				return $this->buildCellActions($rule, $action, $node, $condition['field_name']);
			
			case 'column':
				return $this->buildColumnActions($rule, $action, $node, $condition['field_name']);
			
			default:
				return $this->buildCustomTargetActions($rule, $action, $node);
		}
	}
	
	/**
	 * Build row-level actions
	 *
	 * @param string $rule
	 * @param mixed $action
	 * @return string
	 */
	private function buildRowActions($rule, $action) {
		if ($rule === 'replace') {
			return "$(row).children('td').text('{$action}');";
		}
		
		return "$(row).children('td').css({'{$rule}': '{$action}'});";
	}
	
	/**
	 * Build cell-level actions
	 *
	 * @param string $rule
	 * @param mixed $action
	 * @param array $node
	 * @param string $fieldName
	 * @return string
	 */
	private function buildCellActions($rule, $action, $node, $fieldName) {
		$cellSelector = "$(cells[\"{$node['field_name']}\"])";
		
		switch ($rule) {
			case 'prefix':
				return "{$cellSelector}.text(\"{$action}\" + data.{$fieldName});";
			
			case 'suffix':
				return "{$cellSelector}.text(data.{$fieldName} + \"{$action}\");";
			
			case 'prefix&suffix':
				if (is_array($action) && count($action) >= 2) {
					return "{$cellSelector}.text(\"{$action[0]}\" + data.{$fieldName} + \"{$action[1]}\");";
				}
				return '';
			
			case 'replace':
				return $this->buildReplaceAction($cellSelector, $action);
			
			default:
				return "{$cellSelector}.css({'{$rule}': '{$action}'});";
		}
	}
	
	/**
	 * Build column-level actions
	 *
	 * @param string $rule
	 * @param mixed $action
	 * @param array $node
	 * @param string $fieldName
	 * @return string
	 */
	private function buildColumnActions($rule, $action, $node, $fieldName) {
		// Column actions are similar to cell actions
		return $this->buildCellActions($rule, $action, $node, $fieldName);
	}
	
	/**
	 * Build custom target actions
	 *
	 * @param string $rule
	 * @param mixed $action
	 * @param array $node
	 * @return string
	 */
	private function buildCustomTargetActions($rule, $action, $node) {
		if (empty($node['field_target'])) {
			return '';
		}
		
		$cellSelector = "$(cells[\"{$node['field_target']}\"])";
		
		if ($rule === 'replace') {
			return $this->buildReplaceAction($cellSelector, $action);
		}
		
		return "{$cellSelector}.css({'{$rule}': '{$action}'});";
	}
	
	/**
	 * Build replace action JavaScript
	 *
	 * @param string $cellSelector
	 * @param mixed $action
	 * @return string
	 */
	private function buildReplaceAction($cellSelector, $action) {
		switch ($action) {
			case 'integer':
				return "{$cellSelector}.text(parseInt({$cellSelector}.text()));";
			
			case 'float':
				return "{$cellSelector}.text(parseFloat({$cellSelector}.text()).toFixed(2));";
			
			default:
				if (strpos($action, 'float|') === 0) {
					$parts = explode('|', $action);
					$precision = intval($parts[1] ?? 2);
					return "{$cellSelector}.text(parseFloat({$cellSelector}.text()).toFixed({$precision}));";
				}
				
				return "{$cellSelector}.text('{$action}');";
		}
	}

	/**
	 * Determine HTTP method based on data info and fallback logic
	 * 
	 * @param array $data_info
	 * @return string
	 */
	private function determineHttpMethod($data_info) {
		// Priority order: data_info method > class method > default GET
		if (!empty($data_info['http_method'])) {
			return strtoupper($data_info['http_method']);
		}
		
		if (!empty($this->method)) {
			return strtoupper($this->method);
		}
		
		// Check if secure mode is enabled
		if (!empty($data_info['secure_mode']) && $data_info['secure_mode'] === true) {
			return 'POST';
		}
		
		// Default to GET for backward compatibility
		return 'GET';
	}
	
	/**
	 * Get JavaScript contain match expression
	 *
	 * @param string $data
	 * @param string|null $match_contained
	 * @return string
	 */
	private function getJsContainMatch($data, $match_contained = null) {
		$match = null;
		if ('!=' === $match_contained || '!==' === $match_contained) $match = false;
		if ('==' === $match_contained || '===' === $match_contained) $match = true;
		
		if (true  == $match) return ":contains(\"{$data}\")";
		if (false == $match) return ":not(:contains(\"{$data}\"))";
		
		return "";
	}

	/**
	 * Generate filter button HTML
	 *
	 * @param array $data Filter configuration
	 * @return string|false Filter button HTML or false
	 */
	protected function filterButton(array $data) {
		if (!$this->isFilterEnabled($data)) {
			return false;
		}
		
		$btn_class = $this->getFilterButtonClass($data);
		$attributes = $this->buildFilterButtonAttributes($data);
		
		return sprintf(
			'<button type="button" class="%s %s" %s>%s</button>',
			$btn_class,
			$data['id'],
			$attributes,
			htmlspecialchars($data['button_label'], ENT_QUOTES, 'UTF-8')
		);
	}
	
	/**
	 * Check if filter is enabled
	 *
	 * @param array $data
	 * @return bool
	 */
	private function isFilterEnabled(array $data) {
		if (empty($data['searchable'])) {
			return false;
		}
		
		if (!empty($data['searchable']['all::columns']) && 
			false === $data['searchable']['all::columns']) {
			return false;
		}
		
		return $data['searchable'] !== false && !empty($data['class']);
	}
	
	/**
	 * Get filter button CSS class
	 *
	 * @param array $data
	 * @return string
	 */
	private function getFilterButtonClass(array $data) {
		return $data['class'] ?? 'btn btn-primary btn-flat btn-lg mt-3';
	}
	
	/**
	 * Build filter button attributes
	 *
	 * @param array $data
	 * @return string
	 */
	private function buildFilterButtonAttributes(array $data) {
		$id = htmlspecialchars($data['id'], ENT_QUOTES, 'UTF-8');
		return "data-toggle=\"modal\" data-target=\".{$id}\"";
	}

	/**
	 * Generate filter modal box HTML
	 *
	 * @param array $data Modal configuration
	 * @return string|false Modal HTML or false
	 */
	protected function filterModalbox(array $data) {
		if (!$this->isFilterEnabled($data) || empty($data['modal_content']['html'])) {
			return false;
		}
		
		$modalConfig = $this->buildModalConfiguration($data);
		return $this->generateModalHTML($modalConfig);
	}
	
	/**
	 * Build modal configuration array
	 *
	 * @param array $data
	 * @return array
	 */
	private function buildModalConfiguration(array $data) {
		return [
			'id' => htmlspecialchars($data['id'], ENT_QUOTES, 'UTF-8'),
			'title' => htmlspecialchars($data['modal_title'] ?? '', ENT_QUOTES, 'UTF-8'),
			'name' => htmlspecialchars($data['modal_content']['name'] ?? '', ENT_QUOTES, 'UTF-8'),
			'html' => $data['modal_content']['html'],
			'attributes' => $this->buildModalAttributes($data['attributes'] ?? []),
			'current_url' => htmlspecialchars(url(diy_current_route()->uri), ENT_QUOTES, 'UTF-8')
		];
	}
	
	/**
	 * Build modal HTML attributes string
	 *
	 * @param array $attributes
	 * @return string
	 */
	private function buildModalAttributes(array $attributes) {
		$attributeString = '';
		foreach ($attributes as $key => $value) {
			$key = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
			$value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
			$attributeString .= " {$key}=\"{$value}\"";
		}
		return $attributeString;
	}
	
	/**
	 * Generate complete modal HTML structure
	 *
	 * @param array $config
	 * @return string
	 */
	private function generateModalHTML(array $config) {
		$modalTemplate = '
			<div class="modal fade %s" role="dialog"%s>
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title">%s</h4>
							<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						<form name="%s" method="GET" action="%s">
							<div class="modal-body">%s</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-primary">Filter</button>
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							</div>
						</form>
					</div>
				</div>
			</div>';
		
		return sprintf(
			$modalTemplate,
			$config['id'],
			$config['attributes'],
			$config['title'],
			$config['name'],
			$config['current_url'],
			$config['html']
		);
	}
}
