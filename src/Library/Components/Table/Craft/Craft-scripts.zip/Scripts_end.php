﻿	protected function filterButton(array $data) {
		if (!empty($data['searchable'])) {
			if (!empty($data['searchable']['all::columns'])) {
				if (false === $data['searchable']['all::columns']) {
					return false;
				}
			}
			
			if (false !== $data['searchable'] && !empty($data['class'])) {
				$btn_class = $data['class'];
				if (empty($data['class'])) $btn_class = 'btn btn-primary btn-flat btn-lg mt-3';
				
				return '<button type="button" class="' . $btn_class . ' ' . $data['id'] . '" data-toggle="modal" data-target=".' . $data['id'] . '">' . $data['button_label'] . '</button>';
			}
		}
		
		return false;
	}
	
	protected function filterModalbox(array $data) {
		$current_url = url(diy_current_route()->uri);
		if (!empty($data['searchable'])) {
			if (!empty($data['searchable']['all::columns'])) {
				if (false === $data['searchable']['all::columns']) {
					return false;
				}
			}
			
			if (!empty($data['modal_content']['html'])) {
				$attributes = '';
				if (!empty($data['attributes'])) {
					foreach ($data['attributes'] as $key => $attr) {
						$attributes .= " {$key}=\"{$attr}\"";
					}
				}
				
				$title = null;
				if (!empty($data['modal_title'])) $title = $data['modal_title'];
				$name = null;
				if (!empty($data['modal_content']['name'])) $name = $data['modal_content']['name'];
				$content = null;
				if (!empty($data['modal_content']['html'])) $content = $data['modal_content']['html'];
				
				// Determine form method based on configuration
				$formMethod = $this->getFilterFormMethod($data);
				$formAction = $this->getFilterFormAction($current_url, $formMethod);
				
				$html  = '<div ' . $attributes . '>';
					$html .= '<div id="' . $data['id'] . '_cdyFILTERFormBox" class="modal-dialog modal-lg" role="document">';
						$html .= '<form action="' . $formAction . '" method="' . $formMethod . '" id="' . $data['id'] . '_cdyFILTERForm" role="form">';
							$html .= '<div class="modal-content">';
								$html .= '<div id="' . $data['id'] . '_cdyProcessing" class="dataTables_processing" style="display:none"></div>';
								$html .= '<div class="modal-header">';
									$html .= '<h5 class="modal-title" id="">' . $title . ' Data ' . $name . '</h5>';
									$html .= '<button type="button" class="close" data-dismiss="modal" aria-label="Close">';
										$html .= '<span aria-hidden="true">&times;</span>';
									$html .= '</button>';
								$html .= '</div>';
								
								// Add necessary hidden fields
								$html .= '<input type="hidden" name="_token" value="' . csrf_token() . '" />';
								
								// For POST method, add necessary parameters as hidden fields
								if ('POST' === $formMethod) {
									$html .= '<input type="hidden" name="renderDataTables" value="true" />';
									$html .= '<input type="hidden" name="filters" value="true" />';
								}
								
								$html .= $content;
							$html .= '</div>';
						$html .= '</form>';
					$html .= '</div>';
				$html .= '</div>';
				
				return $html;
			}
		}
		
	}
	
	private function export($id, $url, $type = 'csv', $delimeter = '|') {
		$connection    = null;
		if (diy_string_contained($id, '::')) {
			$stringID   = explode('::', $id);
			$id         = $stringID[0];
			$connection = diy_encrypt($stringID[1]);
		}
		
		$varTableID	= explode('-', $id);
		$varTableID	= implode('', $varTableID);
		$modalID    = "{$id}_cdyFILTERmodalBOX";
		$filterID   = "{$id}_cdyFILTER";
		$exportID   = 'export_' . str_replace('-', '_', $id) . '_cdyFILTERField';
		$token      = csrf_token();
		
		$filters = [];
		if (!empty($this->conditions['where'])) {
			$filters = $this->conditions['where'];
		}
		$filter = json_encode($filters);
		
		return "exportFromModal('{$modalID}', '{$exportID}', '{$filterID}', '{$token}', '{$url}', '{$connection}', {$filter});";
	}
	
	private function filter($id, $url) {
		$varTableID	= explode('-', $id);
		$varTableID	= implode('', $varTableID);
		
		return "diyDataTableFilters('{$id}', '{$url}', cody_{$varTableID}_dt);";
	}
	
	private function initComplete($id, $location = 'footer') {
		if (false === $location) {
			$js = "initComplete: function() {document.getElementById('{$id}').deleteTFoot();}";
		} else {
			if (true === $location) {
				$location = 'footer';
			}
			
			$js  = "initComplete: function() {";
				$js .= "this.api().columns().every(function(n) {";
					$js .= "if (n > 1) {";
						$js .= "var column = this;";
						$js .= "var input  = document.createElement(\"input\");";
						$js .= "$(input).attr({";
							$js .= "'class':'form-control',";
							$js .= "'placeholder': 'search'";
						$js .= "}).appendTo($(column.{$location}()).empty()).on('change', function () {";
							$js .= "column.search($(this).val(), false, false, true).draw();";
						$js .= "});";
					$js .= "}";
				$js .= "});";
			$js .= "}";
		}
		
		return $js;
	}

	/** 
	 * Set Buttons
	 * @return
		$buttonset = '[
			{
				extend:"collection",
				exportOptions:{columns:":visible:not(:last-child)"},
				text:"<i class=\"fa fa-external-link\" aria-hidden=\"true\"></i> <u>E</u>xport",
				buttons:[{text:"Excel",buttons:"excel"}, "csv", "pdf"],
				key:{key:"e",altKey:true}
			},
			"copy",
			"print"
		]';
	 */
	private function setButtons($id, $button_sets = []) {
		$buttons = [];
		foreach ($button_sets as $button) {
			
			$button = trim($button);
			$option = null;
			$options[$button] = [];
			
			if (diy_string_contained($button, '|')) {
				$splits = explode('|', $button);
				foreach ($splits as $split) {
					if (diy_string_contained($split, ':')) {
						$options[$button][] = $split;
					} else {
						$button = $split;
					}
				}
			}
			
			if (!empty($options[$button])) $option = implode(',', $options[$button]);
			$buttons[] = '{extend:"' . $button . '", ' . $option . '}';
		}
		
		return '[' . implode(',', $buttons) . ']';
	}

	/**
	 * Get filter form method based on configuration
	 * 
	 * @param array $data
	 * @return string
	 */
	private function getFilterFormMethod($data) {
		// Check if data contains method information
		if (!empty($data['http_method'])) {
			return strtoupper($data['http_method']);
		}
		
		// Check if secure mode is enabled
		if (!empty($data['secure_mode']) && $data['secure_mode'] === true) {
			return 'POST';
		}
		
		// Check class property
		if (!empty($this->method)) {
			return strtoupper($this->method);
		}
		
		// Default to GET for backward compatibility
		return 'GET';
	}

	/**
	 * Get filter form action URL based on method
	 * 
	 * @param string $current_url
	 * @param string $method
	 * @return string
	 */
	private function getFilterFormAction($current_url, $method) {
		if ('POST' === $method) {
			// For POST, return clean URL without query parameters
			return $current_url;
		}
		
		// For GET, include necessary parameters in URL
		return $current_url . '?renderDataTables=true&filters=true';
	}
}
